  * Advanced Color Gradient using online version of FastLED.
    * https://wokwi.com/projects/285170662915441160
  * LedMapper tool for irregular shapes
    * https://github.com/jasoncoon/led-mapper
  * list of projects on reddit:
    * https://www.reddit.com/r/FastLED/wiki/index/user_examples/
  * mesh networked esp32 with mutli wifi connections for redundancy

  * https://github.com/Souravgoswami/Arduino-FastLED-Cool-Effects
  * FastLED-IR: https://github.com/marcmerlin/FastLED-IR
    * https://github.com/marcmerlin/NeoMatrix-FastLED-IR?tab=readme-ov-file

  * Tree IR:
    * https://www.evilgeniuslabs.org/tree-v2

  * Esp32 server for fastled
    * https://github.com/jasoncoon/esp32-fastled-webserver

  * Strip tease - cool fx for strips
    * https://github.com/lpaolini/Striptease?tab=readme-ov-file


* Soulematelights:
  * https://editor.soulmatelights.com/gallery


* https://github.com/marcmerlin/FastLED_NeoMatrix_SmartMatrix_LEDMatrix_GFX_Demos/blob/master/LEDMatrix/Table_Mark_Estes/Table_Mark_Estes.ino


* AMAZING processing.js artist
  * https://x.com/Hau_kun

* llm-min.txt
  * https://github.com/marv1nnnnn/llm-min.txt